from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        # ✅ Check if user already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken. Try another.")
            return redirect('register')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already used. Try another.")
            return redirect('register')

        # Create inactive user
        user = User.objects.create_user(username=username, email=email, password=password)
        user.is_active = False  # will be activated by email
        user.save()

        # ... continue with email verification logic ...
        messages.success(request, "Account created. Check your email to activate it.")
        return redirect('home')

    return render(request, 'register.html')
